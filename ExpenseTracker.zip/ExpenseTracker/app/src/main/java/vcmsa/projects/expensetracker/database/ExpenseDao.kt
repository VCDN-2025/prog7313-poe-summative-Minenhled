package vcmsa.projects.expensetracker.database



import androidx.lifecycle.LiveData

import vcmsa.projects.expensetracker.data.models.Expense
import java.util.Date


interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): LiveData<List<Expense>>

    annotation class Query(val value: String)

    @Query("SELECT * FROM expenses WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    fun getExpensesByDateRange(startDate: Date, endDate: Date): LiveData<List<Expense>>

    @Query("SELECT * FROM expenses WHERE category = :category ORDER BY date DESC")
    fun getExpensesByCategory(category: String): LiveData<List<Expense>>

    @Query("SELECT SUM(amount) FROM expenses WHERE date BETWEEN :startDate AND :endDate")
    fun getTotalExpensesByDateRange(startDate: Date, endDate: Date): LiveData<Double?>

    @Query("SELECT category, SUM(amount) as total FROM expenses WHERE date BETWEEN :startDate AND :endDate GROUP BY category")
    fun getCategoryTotals(startDate: Date, endDate: Date): LiveData<List<CategoryTotal>>



    @Query("SELECT * FROM expenses WHERE syncedToCloud = 0")
    suspend fun getUnsyncedExpenses(): List<Expense>

    @Query("UPDATE expenses SET syncedToCloud = 1 WHERE id = :id")
    suspend fun markAsSynced(id: Long)
}

data class CategoryTotal(
    val category: String,
    val total: Double
)