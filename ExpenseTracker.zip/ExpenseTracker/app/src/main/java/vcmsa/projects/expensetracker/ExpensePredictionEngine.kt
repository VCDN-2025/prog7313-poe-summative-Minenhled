package vcmsa.projects.expensetracker

import vcmsa.projects.expensetracker.data.models.Expense

class ExpensePredictionEngine {

    fun predictNextMonthExpenses(historicalExpenses: List<Expense>): Map<String, Double> {
        val monthlyAverages = mutableMapOf<String, Double>()

        historicalExpenses.groupBy { it.category }.forEach { (category, expenses) ->
            // Group expenses by month-year string, assuming 'date' is a Firebase Timestamp or java.util.Date
            val monthlyTotals = expenses.groupBy {
                val date = it.date.toDate() // Convert Timestamp to Date if needed
                "${date.month}-${date.year}" // Note: month is 0-based, year is years since 1900
            }.mapValues { entry -> entry.value.sumOf { expense -> expense.amount } }

            val average = monthlyTotals.values.average()
            val trend = calculateTrend(monthlyTotals.values.toList())

            monthlyAverages[category] = average * (1 + trend)
        }

        return monthlyAverages
    }

    private fun calculateTrend(values: List<Double>): Double {
        if (values.size < 2) return 0.0

        val recent = values.takeLast(3).average()
        val older = values.dropLast(3).takeIf { it.isNotEmpty() }?.average() ?: recent

        return (recent - older) / older
    }
}
