package vcmsa.projects.expensetracker

import vcmsa.projects.expensetracker.data.models.Expense

class BudgetRecommendationEngine {
    fun generateRecommendations(expenses: List<Expense>): List<BudgetRecommendation> {
        // Group expenses by category and sum amounts
        val categoryTotals = expenses.groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { expense -> expense.amount } }

        val recommendations = mutableListOf<BudgetRecommendation>()

        // Analyze spending patterns and suggest optimizations
        categoryTotals.forEach { (category, total) ->
            val avgMonthlySpending = total / 12.0 // Assuming yearly data

            val recommendation = when {
                avgMonthlySpending > 1000 -> "Consider reducing $category expenses by 10%"
                avgMonthlySpending > 500 -> "Your $category spending is moderate"
                else -> "$category spending is well controlled"
            }

            recommendations.add(BudgetRecommendation(category, recommendation, total))
        }

        return recommendations
    }
}

data class BudgetRecommendation(
    val category: String,
    val recommendation: String,
    val currentSpending: Double
)
