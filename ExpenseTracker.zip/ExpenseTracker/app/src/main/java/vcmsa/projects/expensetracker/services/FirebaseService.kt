package vcmsa.projects.expensetracker.services

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseService @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {

    private val currentUserId: String?
        get() = auth.currentUser?.uid

    // Transaction data class
    data class Transaction(
        val id: String = "",
        val amount: Double = 0.0,
        val category: String = "",
        val description: String = "",
        val date: Date = Date(),
        val type: TransactionType = TransactionType.EXPENSE
    )

    enum class TransactionType { EXPENSE, INCOME }

    data class SpendingGoal(
        val id: String = "",
        val category: String = "",
        val minAmount: Double = 0.0,
        val maxAmount: Double = 0.0,
        val period: GoalPeriod = GoalPeriod.MONTHLY
    )

    enum class GoalPeriod { WEEKLY, MONTHLY }

    // Add new transaction
    suspend fun addTransaction(transaction: Transaction): Result<String> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))
            val docRef = firestore
                .collection("users")
                .document(userId)
                .collection("transactions")
                .add(transaction.copy(id = ""))
                .await()

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Get transactions with date range filter
    suspend fun getTransactions(
        startDate: Date? = null,
        endDate: Date? = null,
        category: String? = null
    ): Result<List<Transaction>> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))

            var query: Query = firestore
                .collection("users")
                .document(userId)
                .collection("transactions")
                .orderBy("date", Query.Direction.DESCENDING)

            startDate?.let { query = query.whereGreaterThanOrEqualTo("date", it) }
            endDate?.let { query = query.whereLessThanOrEqualTo("date", it) }
            category?.let { query = query.whereEqualTo("category", it) }

            val snapshot = query.get().await()
            val transactions = snapshot.documents.mapNotNull { doc ->
                doc.toObject(Transaction::class.java)?.copy(id = doc.id)
            }

            Result.success(transactions)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Real-time transaction updates
    fun getTransactionsFlow(): Flow<List<Transaction>> = flow {
        val userId = currentUserId ?: return@flow

        firestore
            .collection("users")
            .document(userId)
            .collection("transactions")
            .orderBy("date", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                snapshot?.let { querySnapshot ->
                    val transactions = querySnapshot.documents.mapNotNull { doc ->
                        doc.toObject(Transaction::class.java)?.copy(id = doc.id)
                    }
                    // Note: In a real app, you'd use a callback mechanism here
                    // This is simplified for demonstration
                }
            }
    }

    // Set spending goal
    suspend fun setSpendingGoal(goal: SpendingGoal): Result<String> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))
            val docRef = firestore
                .collection("users")
                .document(userId)
                .collection("goals")
                .add(goal.copy(id = ""))
                .await()

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Get spending goals
    suspend fun getSpendingGoals(): Result<List<SpendingGoal>> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))

            val snapshot = firestore
                .collection("users")
                .document(userId)
                .collection("goals")
                .get()
                .await()

            val goals = snapshot.documents.mapNotNull { doc ->
                doc.toObject(SpendingGoal::class.java)?.copy(id = doc.id)
            }

            Result.success(goals)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Calculate category spending for period
    suspend fun getCategorySpending(
        startDate: Date,
        endDate: Date
    ): Result<Map<String, Double>> {
        return try {
            val transactionsResult = getTransactions(startDate, endDate)
            if (transactionsResult.isFailure) {
                return Result.failure(transactionsResult.exceptionOrNull()!!)
            }

            val transactions = transactionsResult.getOrNull() ?: emptyList()
            val categorySpending = transactions
                .filter { it.type == TransactionType.EXPENSE }
                .groupBy { it.category }
                .mapValues { (_, transactions) ->
                    transactions.sumOf { it.amount }
                }

            Result.success(categorySpending)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Check goal achievement for past month
    suspend fun checkGoalAchievement(): Result<Map<String, GoalStatus>> {
        return try {
            val calendar = Calendar.getInstance()
            val endDate = calendar.time
            calendar.add(Calendar.MONTH, -1)
            val startDate = calendar.time

            val goalsResult = getSpendingGoals()
            val spendingResult = getCategorySpending(startDate, endDate)

            if (goalsResult.isFailure || spendingResult.isFailure) {
                return Result.failure(Exception("Failed to fetch data"))
            }

            val goals = goalsResult.getOrNull() ?: emptyList()
            val spending = spendingResult.getOrNull() ?: emptyMap()

            val goalStatus = goals.associate { goal ->
                val actualSpending = spending[goal.category] ?: 0.0
                val status = when {
                    actualSpending < goal.minAmount -> GoalStatus.UNDER_MINIMUM
                    actualSpending > goal.maxAmount -> GoalStatus.OVER_MAXIMUM
                    else -> GoalStatus.WITHIN_RANGE
                }
                goal.category to status
            }

            Result.success(goalStatus)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    enum class GoalStatus {
        UNDER_MINIMUM,
        WITHIN_RANGE,
        OVER_MAXIMUM
    }

    // Update transaction
    suspend fun updateTransaction(transaction: Transaction): Result<Unit> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))
            firestore
                .collection("users")
                .document(userId)
                .collection("transactions")
                .document(transaction.id)
                .set(transaction)
                .await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Delete transaction
    suspend fun deleteTransaction(transactionId: String): Result<Unit> {
        return try {
            val userId = currentUserId ?: return Result.failure(Exception("User not authenticated"))
            firestore
                .collection("users")
                .document(userId)
                .collection("transactions")
                .document(transactionId)
                .delete()
                .await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Get spending summary for dashboard
    suspend fun getSpendingSummary(days: Int = 30): Result<SpendingSummary> {
        return try {
            val calendar = Calendar.getInstance()
            val endDate = calendar.time
            calendar.add(Calendar.DAY_OF_MONTH, -days)
            val startDate = calendar.time

            val transactionsResult = getTransactions(startDate, endDate)
            if (transactionsResult.isFailure) {
                return Result.failure(transactionsResult.exceptionOrNull()!!)
            }

            val transactions = transactionsResult.getOrNull() ?: emptyList()

            val totalExpenses = transactions
                .filter { it.type == TransactionType.EXPENSE }
                .sumOf { it.amount }

            val totalIncome = transactions
                .filter { it.type == TransactionType.INCOME }
                .sumOf { it.amount }

            val categoryBreakdown = transactions
                .filter { it.type == TransactionType.EXPENSE }
                .groupBy { it.category }
                .mapValues { (_, txns) -> txns.sumOf { it.amount } }

            val summary = SpendingSummary(
                totalExpenses = totalExpenses,
                totalIncome = totalIncome,
                netAmount = totalIncome - totalExpenses,
                categoryBreakdown = categoryBreakdown,
                transactionCount = transactions.size
            )

            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    data class SpendingSummary(
        val totalExpenses: Double,
        val totalIncome: Double,
        val netAmount: Double,
        val categoryBreakdown: Map<String, Double>,
        val transactionCount: Int
    )
}


//🔗 Android Developer Portal
//   https://developer.android.com
//   (Official documentation, API guides, and Jetpack libraries)
//
//🔗 Android Studio User Guide
//   https://developer.android.com/studio/intro
//   (Installation, setup, Gradle, and emulator instructions)
//
//🔗 Android Codelabs
//   https://developer.android.com/codelabs
//   (Hands-on tutorials for Room, ViewModel, Compose, etc.)
//
//🔗 Android API Reference
//   https://developer.android.com/reference
//   (Full SDK API list for Java & Kotlin)
//
//🔗 Stack Overflow - Android
//   https://stackoverflow.com/questions/tagged/android
//   (Community Q&A, error troubleshooting)
//
//🔗 Android GitHub Samples
//   https://github.com/android
//   (Official sample projects for Android features)
//
//🔗 Kotlin Playground
//   https://play.kotlinlang.org
//   (Practice Kotlin syntax online)
//
//🔗 JetBrains Academy
//   https://www.jetbrains.com/academy/
//   (Courses for Kotlin, Java, Android development)



