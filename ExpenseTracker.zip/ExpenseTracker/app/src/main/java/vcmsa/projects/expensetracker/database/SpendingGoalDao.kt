package vcmsa.projects.expensetracker.database

import androidx.room.*
import vcmsa.projects.expensetracker.data.models.SpendingGoal

@Dao
interface SpendingGoalDao {

    @Query("DELETE FROM SpendingGoal WHERE id = :id")
    suspend fun deleteGoalById(id: Long)

    @Query("SELECT * FROM SpendingGoal WHERE syncedToCloud = 0")
    suspend fun getUnsyncedGoals(): List<SpendingGoal>

    @Query("UPDATE SpendingGoal SET syncedToCloud = 1 WHERE id = :id")
    suspend fun markGoalAsSynced(id: Long)

    @Query("UPDATE SpendingGoal SET syncedToCloud = 1 WHERE id IN (:ids)")
    suspend fun markGoalsAsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM SpendingGoal")
    suspend fun getGoalCount(): Int

    @Query("SELECT COUNT(*) FROM SpendingGoal WHERE isCompleted = 0")
    suspend fun getActiveGoalCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(spendingGoal: SpendingGoal): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(spendingGoals: List<SpendingGoal>): List<Long>

    @Update
    suspend fun updateGoal(spendingGoal: SpendingGoal)

    @Delete
    suspend fun deleteGoal(spendingGoal: SpendingGoal)
}


//🔗 Android Developer Portal
//   https://developer.android.com
//   (Official documentation, API guides, and Jetpack libraries)
//
//🔗 Android Studio User Guide
//   https://developer.android.com/studio/intro
//   (Installation, setup, Gradle, and emulator instructions)
//
//🔗 Android Codelabs
//   https://developer.android.com/codelabs
//   (Hands-on tutorials for Room, ViewModel, Compose, etc.)
//
//🔗 Android API Reference
//   https://developer.android.com/reference
//   (Full SDK API list for Java & Kotlin)
//
//🔗 Stack Overflow - Android
//   https://stackoverflow.com/questions/tagged/android
//   (Community Q&A, error troubleshooting)
//
//🔗 Android GitHub Samples
//   https://github.com/android
//   (Official sample projects for Android features)
//
//🔗 Kotlin Playground
//   https://play.kotlinlang.org
//   (Practice Kotlin syntax online)
//
//🔗 JetBrains Academy
//   https://www.jetbrains.com/academy/
//   (Courses for Kotlin, Java, Android development)


