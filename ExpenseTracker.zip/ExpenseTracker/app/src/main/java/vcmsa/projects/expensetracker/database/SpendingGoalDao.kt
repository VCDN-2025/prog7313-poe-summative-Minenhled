package vcmsa.projects.expensetracker.database

import androidx.room.*
import vcmsa.projects.expensetracker.data.models.SpendingGoal

@Dao
interface SpendingGoalDao {

    @Query("DELETE FROM SpendingGoal WHERE id = :id")
    suspend fun deleteGoalById(id: Long)

    @Query("SELECT * FROM SpendingGoal WHERE syncedToCloud = 0")
    suspend fun getUnsyncedGoals(): List<SpendingGoal>

    @Query("UPDATE SpendingGoal SET syncedToCloud = 1 WHERE id = :id")
    suspend fun markGoalAsSynced(id: Long)

    @Query("UPDATE SpendingGoal SET syncedToCloud = 1 WHERE id IN (:ids)")
    suspend fun markGoalsAsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM SpendingGoal")
    suspend fun getGoalCount(): Int

    @Query("SELECT COUNT(*) FROM SpendingGoal WHERE isCompleted = 0")
    suspend fun getActiveGoalCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(spendingGoal: SpendingGoal): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(spendingGoals: List<SpendingGoal>): List<Long>

    @Update
    suspend fun updateGoal(spendingGoal: SpendingGoal)

    @Delete
    suspend fun deleteGoal(spendingGoal: SpendingGoal)
}


