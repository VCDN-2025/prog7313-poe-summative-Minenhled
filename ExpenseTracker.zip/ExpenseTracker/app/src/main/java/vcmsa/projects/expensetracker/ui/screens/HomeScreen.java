package vcmsa.projects.expensetracker.ui.screens;

import android.app.Activity;
import android.os.Bundle;

public class HomeScreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set your layout here, for example:
        // setContentView(R.layout.activity_home_screen);
    }
}

