package vcmsa.projects.expensetracker.database

import android.content.Context
import androidx.room.*

import vcmsa.projects.expensetracker.data.models.Expense
import vcmsa.projects.expensetracker.data.models.SpendingGoal
import java.util.Date

@Database(
    entities = [Expense::class, SpendingGoal::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ExpenseDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    abstract fun goalDao(): SpendingGoal

    companion object {
        @Volatile
        private var INSTANCE: ExpenseDatabase? = null

        fun getDatabase(context: Context): ExpenseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ExpenseDatabase::class.java,
                    "expense_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}





//🔗 Android Developer Portal
//   https://developer.android.com
//   (Official documentation, API guides, and Jetpack libraries)
//
//🔗 Android Studio User Guide
//   https://developer.android.com/studio/intro
//   (Installation, setup, Gradle, and emulator instructions)
//
//🔗 Android Codelabs
//   https://developer.android.com/codelabs
//   (Hands-on tutorials for Room, ViewModel, Compose, etc.)
//
//🔗 Android API Reference
//   https://developer.android.com/reference
//   (Full SDK API list for Java & Kotlin)
//
//🔗 Stack Overflow - Android
//   https://stackoverflow.com/questions/tagged/android
//   (Community Q&A, error troubleshooting)
//
//🔗 Android GitHub Samples
//   https://github.com/android
//   (Official sample projects for Android features)
//
//🔗 Kotlin Playground
//   https://play.kotlinlang.org
//   (Practice Kotlin syntax online)
//
//🔗 JetBrains Academy
//   https://www.jetbrains.com/academy/
//   (Courses for Kotlin, Java, Android development)




open class RoomDatabase {

}

class Converters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}
