package vcmsa.projects.expensetracker.utils

import org.junit.jupiter.api.Assertions.*

class CurrencyUtilsTest {

    @org.junit.jupiter.api.Test
    fun formatAmount() {
    }

    @org.junit.jupiter.api.Test
    fun formatAmountWithoutSymbol() {
    }

    @org.junit.jupiter.api.Test
    fun parseAmount() {
    }

    @org.junit.jupiter.api.Test
    fun isValidAmount() {
    }
}