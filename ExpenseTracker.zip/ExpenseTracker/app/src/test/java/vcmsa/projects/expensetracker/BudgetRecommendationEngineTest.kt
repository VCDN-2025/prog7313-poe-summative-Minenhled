package vcmsa.projects.expensetracker

import org.junit.jupiter.api.Assertions.*

import org.junit.jupiter.api.Test

class BudgetRecommendationEngineTest {

    @Test
    fun generateRecommendations() {
    }
}